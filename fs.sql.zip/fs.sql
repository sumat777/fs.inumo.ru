-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Май 12 2024 г., 15:08
-- Версия сервера: 10.4.32-MariaDB
-- Версия PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `fs`
--

-- --------------------------------------------------------

--
-- Структура таблицы `fgroup`
--

CREATE TABLE `fgroup` (
  `id` int(11) NOT NULL,
  `descr` varchar(64) NOT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `deleted1` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `modirec` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Дамп данных таблицы `fgroup`
--

INSERT INTO `fgroup` (`id`, `descr`, `users_id`, `deleted1`, `modirec`) VALUES
(1, 'Кастинг девушек для презентации проекта полуфинал 1 - jpg', 1, 0, '2024-05-12 07:38:44'),
(2, 'Кастинг девушек для презентации проекта полуфинал 2 - jpg', 1, 0, '2024-05-12 07:40:54'),
(4, 'Кастинг девушек для презентации проекта полуфинал 3 - gif', 1, 0, '2024-05-12 07:43:40'),
(5, 'Кастинг девушек для презентации проекта финал', 1, 0, '2024-05-12 07:45:42'),
(6, 'Файлы с именами на русском языке', 1, 0, '2024-05-12 07:47:15'),
(7, 'Примеры шахматный партий в формате gif 20240512', 1, 0, '2024-05-12 07:52:13'),
(8, 'Пять лучших книг писателя Константина Оборотова 20240512 ', 1, 0, '2024-05-12 08:00:11'),
(9, 'Картинки для проекта \"Большая Б\" 20240512', 1, 0, '2024-05-12 12:36:21');

-- --------------------------------------------------------

--
-- Структура таблицы `file4`
--

CREATE TABLE `file4` (
  `id` int(11) NOT NULL,
  `fgroup_id` int(11) NOT NULL,
  `fnorig` varchar(64) DEFAULT NULL,
  `fnserver` varchar(32) DEFAULT NULL,
  `users_id` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `deleted1` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `modirec` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Дамп данных таблицы `file4`
--

INSERT INTO `file4` (`id`, `fgroup_id`, `fnorig`, `fnserver`, `users_id`, `deleted1`, `modirec`) VALUES
(1, 1, 'sample_title_try01.jpg', 'f_20240512_103844_715_001.jpg', 1, 0, '2024-05-12 07:38:44'),
(2, 1, 'sample_title_try02.jpg', 'f_20240512_103844_715_002.jpg', 1, 0, '2024-05-12 07:38:44'),
(3, 1, 'sample_title_try03.jpg', 'f_20240512_103844_715_003.jpg', 1, 0, '2024-05-12 07:38:44'),
(4, 1, 'sample_title_try04.jpg', 'f_20240512_103844_715_004.jpg', 1, 0, '2024-05-12 07:38:44'),
(5, 1, 'sample_title_try05.jpg', 'f_20240512_103844_715_005.jpg', 1, 0, '2024-05-12 07:38:44'),
(6, 2, 'sample_title_try06.jpg', 'f_20240512_104054_297_001.jpg', 1, 0, '2024-05-12 07:40:54'),
(7, 2, 'sample_title_try07.jpg', 'f_20240512_104054_297_002.jpg', 1, 0, '2024-05-12 07:40:54'),
(8, 2, 'sample_title_try08.jpg', 'f_20240512_104054_297_003.jpg', 1, 0, '2024-05-12 07:40:54'),
(9, 2, 'sample_title_try09.jpg', 'f_20240512_104054_297_004.jpg', 1, 0, '2024-05-12 07:40:54'),
(10, 2, 'sample_title_try10.jpg', 'f_20240512_104054_297_005.jpg', 1, 0, '2024-05-12 07:40:54'),
(11, 4, 'sample_title_try01.gif', 'f_20240512_104340_875_001.gif', 1, 0, '2024-05-12 07:43:40'),
(12, 4, 'sample_title_try02.gif', 'f_20240512_104340_875_002.gif', 1, 0, '2024-05-12 07:43:40'),
(13, 4, 'sample_title_try03.gif', 'f_20240512_104340_875_003.gif', 1, 0, '2024-05-12 07:43:40'),
(14, 4, 'sample_title_try04.gif', 'f_20240512_104340_875_004.gif', 1, 0, '2024-05-12 07:43:40'),
(15, 4, 'sample_title_try06.gif', 'f_20240512_104340_875_005.gif', 1, 0, '2024-05-12 07:43:40'),
(16, 5, 'sample_title_try03.jpg', 'f_20240512_104542_644_001.jpg', 1, 0, '2024-05-12 07:45:42'),
(17, 5, 'sample_title_try04.jpg', 'f_20240512_104542_644_002.jpg', 1, 0, '2024-05-12 07:45:42'),
(18, 5, 'sample_title_try05.jpg', 'f_20240512_104542_644_003.jpg', 1, 0, '2024-05-12 07:45:42'),
(19, 5, 'sample_title_try12.jpg', 'f_20240512_104542_644_004.jpg', 1, 0, '2024-05-12 07:45:42'),
(20, 5, 'sample_title_try14.jpg', 'f_20240512_104542_644_005.jpg', 1, 0, '2024-05-12 07:45:42'),
(21, 6, 'Файл с именем на русском языке.gif', 'f_20240512_104715_327_001.gif', 1, 0, '2024-05-12 07:47:15'),
(22, 6, 'Файл с именем на русском языке.jpg', 'f_20240512_104715_327_002.jpg', 1, 0, '2024-05-12 07:47:15'),
(23, 6, 'Файл с именем на русском языке.png', 'f_20240512_104715_327_003.png', 1, 0, '2024-05-12 07:47:15'),
(24, 7, 'game2.gif', 'f_20240512_105213_052_001.gif', 1, 0, '2024-05-12 07:52:13'),
(25, 7, 'game1.gif', 'f_20240512_105213_052_002.gif', 1, 0, '2024-05-12 07:52:13'),
(26, 7, 'game3.gif', 'f_20240512_105213_052_003.gif', 1, 0, '2024-05-12 07:52:13'),
(27, 7, 'game2.gif', 'f_20240512_105213_052_004.gif', 1, 0, '2024-05-12 07:52:13'),
(28, 7, 'game1.gif', 'f_20240512_105213_052_005.gif', 1, 0, '2024-05-12 07:52:13'),
(29, 8, '70361572.jpg', 'f_20240512_110011_934_001.jpg', 1, 0, '2024-05-12 08:00:11'),
(30, 8, '70383148.jpg', 'f_20240512_110011_934_002.jpg', 1, 0, '2024-05-12 08:00:12'),
(31, 8, '70430377.jpg', 'f_20240512_110011_934_003.jpg', 1, 0, '2024-05-12 08:00:12'),
(32, 8, '70458904.jpg', 'f_20240512_110011_934_004.jpg', 1, 0, '2024-05-12 08:00:12'),
(33, 8, '70598638.webp', 'f_20240512_110011_934_005.webp', 1, 0, '2024-05-12 08:00:12'),
(34, 9, 'bb_girl1.jpg', 'f_20240512_153621_416_001.jpg', 1, 0, '2024-05-12 12:36:21'),
(35, 9, 'bb_girl2.jpg', 'f_20240512_153621_416_002.jpg', 1, 0, '2024-05-12 12:36:21'),
(36, 9, 'bb_girl3.jpg', 'f_20240512_153621_416_003.jpg', 1, 0, '2024-05-12 12:36:21'),
(37, 9, 'bb_girl4.jpg', 'f_20240512_153621_416_004.jpg', 1, 0, '2024-05-12 12:36:21'),
(38, 9, 'bb_girl5.jpg', 'f_20240512_153621_416_005.jpg', 1, 0, '2024-05-12 12:36:21');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `fgroup`
--
ALTER TABLE `fgroup`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `descr` (`descr`);

--
-- Индексы таблицы `file4`
--
ALTER TABLE `file4`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `fnserver` (`fnserver`),
  ADD KEY `fk_fgroup_id` (`fgroup_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `fgroup`
--
ALTER TABLE `fgroup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `file4`
--
ALTER TABLE `file4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `file4`
--
ALTER TABLE `file4`
  ADD CONSTRAINT `fk_fgroup_id` FOREIGN KEY (`fgroup_id`) REFERENCES `fgroup` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
