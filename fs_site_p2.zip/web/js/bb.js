/* 
-----
Программы JS для проекта 
Большая Библиотека
bb.inumo.ru
Версия:
ver.1.01 2024-03-16
-----
bb.inumo.ru/web/js/bb.js
-----
Копирайт 2011 - 2099
Примечание о соблюдении авторских прав. 
Вы можете бесплатно и без каких-либо разрешений использовать софт сайта bb.inumo.ru на вашем сайте или блоге.
Также вы можете использовать любой контент или софт bb.inumo.ru - все, что вы должны сделать, это поставить ссылку на bb.inumo.ru
--
Copyright 2011 - 2099
Copyright note. Feel free to use bb.inumo.ru soft for your site or blog if you want. 
Also you can use free any other content and soft of bb.inumo.ru - all you have to do is set back link to bb.inumo.ru
-----
*/

jQuery(document).ready(function() {
//


/*
--
Для проверки: подключаются ли стили и скрипты, работает ли jQuery и т.д.
<div id="test20240316">
--
*/
// jQuery( "#test20240316" ).addClass( "test20240316");

jQuery( "#test20240316_set_style" ).on( "click", function() {
  jQuery( "#test20240316" ).addClass( "test20240316");
} );
//
jQuery( "#test20240316_del_style" ).on( "click", function() {
  jQuery( "#test20240316" ).removeClass( "test20240316");
} );


//
});
//
/*
This is enda of...
jQuery(document).ready(function() {
**************************************************************************************
***** This is The Great Wall (border) between .ready area and after .ready area  *****
**************************************************************************************
*/ 
//
//




/*
**********************************
###
### This is enda... of this file...
###
**********************************
*/
