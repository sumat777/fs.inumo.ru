 /* 
 ----------------------------------------------------------------------------
 AV 20191210
 ezdz2019.js
 ----------------------------------------------------------------------------
В этом файле всякие добавки-дополнения...
 ---------------------------------------------------------------------------
*/

jQuery(document).ready(function() {
//
/*
jQuery('[type="file"]').ezdz({
});
*/
//
/*
--
Запретная область:
--
AV 20191215
Протестировали: не работает.
Решение: не использовать...
--
//

jQuery('div.nodrop1').ezdz({
	text: 'Не мусорить здесь!',
	validators: {
	maxWidth:  0,
	maxHeight: 0
},
reject: function(file, errors) {
if (true) {
	alert(file.name + ' Сюда нельзя бросать файлы!');
}
}
//
}); // jQuery('div.nodrop1').ezdz
//
*/
//



jQuery('input.ezdz2019').ezdz({
});


//

// jQuery('#tester').change( function() {
// jQuery('#file_ezdz2019').change( function() {
jQuery('input.ezdz2019').change( function() {
// jQuery('input#file_ezdz2019').change( function() {
// jQuery('input#file').change( function() {
	console.log('file_ezdz2019.change function');
	var names = [];
	for (var i = 0; i < $(this).get(0).files.length; ++i) {
		names.push($(this).get(0).files[i].name);
	}
	jQuery("input[name=cnt1]").val(i);
//
//	jQuery("textarea[name=files]").val(names);
// Выводится в таком виде: test_enclosed_jpg.jpg,test_enclosed_png.png
names_str = '';
jQuery.each(names,function(index,value){
  // действия, которые будут выполняться для каждого элемента массива
  // index - это текущий индекс элемента массива (число)
  // value - это значение текущего элемента массива
  
  //выведем индекс и значение массива в консоль
  console.log('Индекс: ' + index + '; Значение: ' + value);
  index1 = index+1;
  names_str = names_str + index1 + ') ' + value + "\r\n";
//
}); // jQuery.each
//
jQuery("textarea[name=files]").val(names_str);
//



//
}); // jQuery('#file_ezdz2019').change( function() {
//







//
// *****
//
return true;
//
});
/*
This is enda of...
$(document).ready(function() {
**************************************************************************************
***** This is The Great Wall (border) between .ready area and after .ready area  *****
**************************************************************************************
*/ 
//
//




//
/*
**********************************
###
### This is enda... of this file...
###
**********************************
*/


