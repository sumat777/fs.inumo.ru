<?php
/** @var yii\web\View $this */

use yii\helpers\Html;
use yii\widgets\ActiveForm;

if (empty($model)) {
  $this->title = 'Создание новой группы файлов с загрузкой файлов.';
  $this->params['meta_description'] = 'Создание новой группы файлов с загрузкой файлов. ';
} else {
  $this->title = 'Создание новой группы файлов с загрузкой файлов. Процесс прошел успешно.';
  $this->params['meta_description'] = 'Создание новой группы файлов с загрузкой файлов. Процесс прошел успешно. Результаты с демонстрацией загруженных файлов.';
}


$this->params['breadcrumbs'][] = ['label' => 'Группы файлов', 'url' => ['index']]; // Fgroups
$this->params['breadcrumbs'][] = ['label' => 'Создание новой группы файлов с загрузкой файлов', 'url' => ['uploadmv3']]; 
$this->params['breadcrumbs'][] = $this->title;

$fgroup_link = '<a href="/web/fgroup/view?id=' . trim($model_fg_id) . '" class="link1">Просмотр созданной группы</a>';

\yii\web\YiiAsset::register($this);

?>

<h1><?= Html::encode($this->title) ?></h1>
<?= Html::encode($this->params['meta_description']) ?>
<h4><?= $fgroup_link ?><h4>
<br><br>




<!--//
<br><hr><br>

<pre>
?php
//$model["descr"] = 

//var_dump($model["imageFile"]);
//var_dump($model["imageFiles"]);
//var_dump($this->imageFiles);
//var_dump($this);
//var_dump($model);
//var_dump($model["descr"]);
//var_dump($_POST);
//var_dump($_POST ["Uploadmv3Form"]);
//var_dump($_POST["Uploadmv3Form"]["descr"]);
//var_dump($this->descr); Getting unknown property: yii\web\View::descr
//var_dump($model);
//var_dump($model["descr"]);
//var_dump($model_fg);
//var_dump($model);
//var_dump($descr_gf);
//var_dump($model_fg_id);
//var_dump($cnt_files);
//var_dump($ufname_ext);
//var_dump($fnorig_ar);
//var_dump($model_f4_id_ar);
var_dump($model_f4);
?
</pre>

<br><hr><br>

<br><br>
//-->




<?php
// Undefined variable $model

if (empty($model)) {
?>


<a href="/web/fgroup/uploadmv3" class="link1">Создать новую группу файлов с загрузкой файлов.</a>


<?php
} else {

/*
if (empty($_POST["Uploadmv3Form"]["descr"])) {
  //$descr_gf = 'Если пользователь ввел пустое описание, то его формируем автоматом';
//  $descr_gf = 'Группа файлов ' . date("Y-m-d H:i:s");
// $date = date('m/d/Y h:i:s a', time());
$milliseconds = floor(microtime(true) * 1000);
$mls3 = substr($milliseconds, -3);
//$descr_gf = 'Группа файлов ' . date("Y-m-d H:i:s") . " :: " . time() . " :: " . $milliseconds;
$descr_gf = 'Группа файлов ' . date("Y-m-d H:i:s") . " " . $mls3;
} else {
  $descr_gf = $_POST["Uploadmv3Form"]["descr"];
}
*/

?>
  <h3 style="text-align:center;"><?= $descr_gf ?></h3>
  <br>
<?php
  $nn = 0;
  foreach ($model["imageFiles"] as $file) {
    $nn++;
?>

    <h4 style="text-align:center;">Файл номер <?= $nn ?></h4>
    <figure class="div_pic_center">
    <a href="/web/fs/1/<?= $file->name ?>" target="_blank">
    <img src="/web/fs/1/<?= $file->name ?>" class="pic_center_border10_width80p" alt="Загруженный файл" title="Загруженный файл">
    </a>
    <figcaption>Файл: <?= $file->name ?> :: Размер: <?= $file->size ?></figcaption>
    </figure>
    <br><br>

<?php
  }


}
?>

<br><hr><br>
