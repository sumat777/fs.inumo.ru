<?php

use yii\helpers\Html;

use yii\widgets\ActiveForm;

use app\models\UploadForm;
use yii\web\UploadedFile;

/** @var yii\web\View $this */
/** @var app\models\Fgroup $model */

$this->title = 'Загрузка файлов'; // 'Create Fgroup'

$this->params['meta_description'] = 'Можно загрузить до 20-ти файлов.';

$this->params['breadcrumbs'][] = ['label' => 'Группы файлов', 'url' => ['index']]; // Fgroups
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fgroup-create">

  <h1><?= Html::encode($this->title) ?></h1>
  <h3><?= Html::encode($this->params['meta_description']) ?></h3>



<?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]) ?>

    <?= $form->field($model, 'imageFile')->fileInput() ?>

    <button>Submit</button>

<?php ActiveForm::end() ?>


</div>
