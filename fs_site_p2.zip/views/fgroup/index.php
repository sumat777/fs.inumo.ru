<?php

use app\models\Fgroup;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use yii\widgets\Pjax;
/** @var yii\web\View $this */
/** @var app\models\FgroupSearch $searchModel */
/** @var yii\data\ActiveDataProvider $dataProvider */

//$this->title = 'О проекте "' . Yii::$app->name . '"';
//$this->title = 'Fgroups';
$this->title = 'Группы файлов';

$this->params['meta_description'] = 'Можно просматривать текущие группы файлов и/или создать новую группу файлов. В каждую группу файлов может входить от 1 до 5-ти файлов.';

$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fgroup-index">

  <h1><?= Html::encode($this->title) ?></h1>
  <h3><?= Html::encode($this->params['meta_description']) ?></h3>

    <p>
<!--//
Create Fgroup
//-->

<!--//
        ?= Html::a('Создать новую группу файлов', ['create'], ['class' => 'btn btn-success']) ?
//-->
        <?= Html::a('Создать новую группу файлов', ['uploadmv3'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'descr',
//            'users_id',
//            'deleted1',
            'modirec',
            [
                'class' => ActionColumn::className(),
                'visibleButtons' => [
                  'update' => false,
                  'delete' => false,
                ],
                'urlCreator' => function ($action, Fgroup $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'id' => $model->id]);
                 }
            ],
        ],
    ]); ?>

    <?php Pjax::end(); ?>

</div>
