<?php
/** @var yii\web\View $this */

use yii\helpers\Html;
use yii\widgets\ActiveForm;

// $this->title = 'Загрузка нескольких файлов. Версия 3.';
$this->title = 'Создание новой группы файлов с загрузкой файлов.';

$this->params['meta_description'] = 'Создание новой группы файлов с загрузкой файлов. В новую группу файлов может входить от 1 до 5-ти файлов. Разрешена загрузка файлов только со следующими расширениями: png, jpg, jpeg, gif, svg, webp.';

$this->params['breadcrumbs'][] = ['label' => 'Группы файлов', 'url' => ['index']]; // Fgroups
$this->params['breadcrumbs'][] = $this->title;

\yii\web\YiiAsset::register($this);
?>

<h1><?= Html::encode($this->title) ?></h1>
<?= Html::encode($this->params['meta_description']) ?>

<br><br>


<!--//
<br><hr><br>

<pre>

?php
//var_dump($model["imageFile"]);
//var_dump($model["imageFiles"]);
//var_dump($model);
//var_dump($model["descr"]);
var_dump($_POST);
//var_dump($_POST["descr"]);
//var_dump($_POST["Uploadmv3Form"]);
//var_dump($this->imageFiles);
//var_dump($this);
?

</pre>

<br><hr><br>
//-->


<?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]) ?>

<?= 
$form->
field($model, 'descr')->
label('Описание группы файлов. Если оставить это поле пустым, то описание будет создано автоматически в формате: Группа файлов 2024-05-11 12:19:57.')
?>

<br>

<?= 
$form->
field($model, 'imageFiles[]')->
label('Файлы для загрузки. Сначала следует добавить от 1 до 5 файлов для загрузки. В результате в полях &quot;Количество&quot; и &quot;Список&quot; отобразится статистика по выбранным файлам. Затем следует нажать кнопку &quot;Загрузить выбранные файлы&quot;.')->
fileInput(['multiple'=>true, 'accept'=>'image/*', 'class'=>'ezdz2019']) 
?>
Важно! Сначала следует выбрать файлы для загрузки, а затем нажать кнопку "Загрузить выбранные файлы". Подготовить к загрузки нужные файлы можно методом "Драг-и-Дроп" ("Тащи-и-Бросай") или просто нажатием на область для размещения файлов. Ниже информация по выбранным файлам. 
<br><br>
Подготовлено к загрузке файлов: 
<br>
Количество: <input type="text" name="cnt1" size="4" style="background-color:#EEFFFF;" readonly>
<br>
Список:<br>
<textarea readonly rows="5" cols="64" name="files" style="background-color:#EEFFFF;"></textarea>

<br><br>

<!--//
<button>Загрузить выбранные файлы</button>
//-->

<?= Html::submitButton('Загрузить выбранные файлы и сделать запись', ['class' => 'btn btn-success']) ?>

<?php ActiveForm::end() ?>

<br><hr><br>
