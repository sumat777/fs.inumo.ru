<?php
/** @var yii\web\View $this */

use yii\helpers\Html;

$this->title = 'API проекта "' . Yii::$app->name . '"';

$this->params['meta_description'] = 'API проекта "' . Yii::$app->name . '". RESTful Web Service APIs. Здесь документация API данного проекта.';

$this->params['breadcrumbs'][] = $this->title;

?>

<!--//
<h1>test20240509/index</h1>
//-->

<h1><?= Html::encode($this->title) ?></h1>
<?= Html::encode($this->params['meta_description']) ?>

<!--//
<p>
    You may change the content of this page by modifying
    the file <code>?= __FILE__; ?</code>.
</p>
//-->

<br><hr><br>

<h3><mark>GET https://fs.inumo.ru/web/file4/api1</mark></h3>
<br>
В ответ на этот запрос система предоставит в формате JSON полный список текущих картинок.

<br><br>
<b>Пример ответа (отрывок)</b>
<br><br>
<textarea name="text" id="code_train01" cols="64" rows="12" class="css_sample1">
{
  "status": true,
  "file4cnt": 33,
  "data": [
    {
      "id": 1,
      "fgroup_id": 1,
      "fnorig": "sample_title_try01.jpg",
      "fnserver": "f_20240512_103844_715_001.jpg",
      "users_id": 1,
      "deleted1": 0,
      "modirec": "2024-05-12 11:38:44"
    },
    {
      "id": 2,
      "fgroup_id": 1,
      "fnorig": "sample_title_try02.jpg",
      "fnserver": "f_20240512_103844_715_002.jpg",
      "users_id": 1,
      "deleted1": 0,
      "modirec": "2024-05-12 11:38:44"
    },
...
</textarea>

<br><br>

<br>
<br><hr><br>

<h3><mark>GET http://fs.inumo.ru/web/file4/api2?id=29</mark></h3>
<br>
В ответ на этот запрос система предоставит в формате JSON информацию по картинке id=29.

<br><br>
<b>Пример ответа</b>
<br><br>
<textarea name="text" id="code_train01" cols="64" rows="12" class="css_sample1">
{
  "status": true,
  "data": {
    "id": 29,
    "fgroup_id": 8,
    "fnorig": "70361572.jpg",
    "fnserver": "f_20240512_110011_934_001.jpg",
    "users_id": 1,
    "deleted1": 0,
    "modirec": "2024-05-12 12:00:11"
  }
}
</textarea>

<br><br>

<br>
<br><hr><br>