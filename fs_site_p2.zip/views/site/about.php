<?php

/** @var yii\web\View $this */

use yii\helpers\Html;

$this->title = 'О проекте "' . Yii::$app->name . '"';

/*
$this->registerMetaTag([
    'name' => 'description',
    'content' => 'О проекте "' . Yii::$app->name . '". Программный комплес, который позволяет загружать файлы на сервер и просматривать выгружать их.',
]);
Надо иметь ввиду, что мета тег 
$this->registerMetaTag(['name' => 'description', 'content' => $this->params['meta_description'] ?? '']);
Уже зарегистрирован здесь: 
\views\layouts\main.php
Здесь, как и на любой другой локальной странице надо просто определить значение: 
$this->params['meta_description']
*/

$this->params['meta_description'] = 'О проекте "' . Yii::$app->name . '". Программный комплес, который позволяет загружать файлы на сервер, просматривать и выгружать их.';

$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

<p>
<!--//
        This is the About page. You may modify the following file to customize its content:
//-->

<?= Html::encode($this->params['meta_description']) ?>

</p>


<br><hr><br>

<b>Информация для пользователя</b>

<br>

<ul>
  <li>Проект предназначен для взаимного обмена графическими файлами. Разрешена загрузка файлов со следующими расширениями: png, jpg, jpeg, gif, svg, webp.</li>
  <li>Для работы в проекте не требуется авторизация.</li>
  <li>Все файлы объединяются в тематические группы. Каждая группа имеет краткое описание (до 64 символов). В каждой группе может быть от 1-го до 5-ти файлов. Нет ограничений на количество создаваемых групп.</li>
  <li>Для хранения на сервере для каждого файла создается новое уникальное имя на английском языке (нижний регистр), цыфры, знаки подчеркивания. Оригинальное имя файла сохраняется в БД.</li>
  <li>Все файлы хранятся на сервере в директории <code>/web/fs/1/</code> в общем доступе.</li>
  <li>У пользователей есть возможность просматривать информацию о загруженных файлах (название файла, дата и время загрузки). В списке файлов есть превью изображений.</li>
  <li>В списках файлов и групп файлов реализованы возможности сортировки и фильтрации по различным критериям, что дает возможность быстрого поиска нужного файла для его просмотра и скачивания.</li>
  <li>Работают несколько <a href="/web/api" class="link1">API</a> для получения информации о загруженных файлах в формате json.</li>
</ul>



<br><hr><br>

<b>Информация для разработчика</b>

<br>

<h4>Установка БД</h4>

<b>1</b>.<br>
<a href="/web/fs/man/fs.sql.zip" class="link1">Скачайте скрипт для установки БД</a>

<br><br>

<b>2</b>.<br>
С помощью любого универсального клиента (например, phpMyAdmin или pgAdmin4) подключитесь к БД и создайте нового пользователя с паролем и новую БД, например:
<br>
<ul>
  <li><b>fsuser</b> - Пользователь БД</li>
  <li><b>fsPass$$$20240512</b> - Пароль Пользователя</li>
  <li><b>fsdb</b> - БД</li>
</ul>

Это данные для примера. Позже их надо будет внести в специальный файл подключения БД.

<br><br>

<b>3</b>.<br>
Выполняем SQL-запрос к базе данных <b>fsdb</b> (скрипт, который мы скачали на шаге <b>1</b>).

<br><br>

<b>Схема взаимосвязей между таблицами БД</b>

<br>

<?= Html::img('/web/fs/man/db_stru.png', ['alt'=>'Схема взаимосвязей между таблицами БД', 'title'=>'Схема взаимосвязей между таблицами БД', 'class'=>'pic1']);?>

<br><br>



<h4>Установка прикладного ПО (Программного Обеспечения)</h4>

<b>1</b>.<br>
<a href="/web/fs/man/fs_site.zip" class="link1">Скачайте дистрибутив с ПО</a>

<br><br>

<b>2</b>.<br>
Разверните скаченный архив в эту папку (например):<br>
<code>d:\web\www\fs_site.localhost\</code>

<br><br>

<b>3</b>.<br>
Внесите изменения в файл:<br>
<code>d:\xampp\apache\conf\extra\httpd-vhosts.conf</code>

<br><br>

<textarea name="text" id="code_train01" cols="64" rows="12" class="css_sample1">
######################### fs_site #########################

<Directory "D:/web/www/fs_site.localhost">
    Options Indexes FollowSymLinks MultiViews
    AllowOverride all
    Order Deny,Allow
    Allow from all
    Require all granted
</Directory>

<VirtualHost *:80>
    ServerAdmin webmaster@fs_site.localhost
    DocumentRoot "D:/web/www/fs_site.localhost"
    ServerName fs_site.localhost
    ServerAlias www.fs_site.localhost
    ErrorLog "D:/web/log/fs_site.localhost/error.log"
    CustomLog "D:/web/log/fs_site.localhost/access.log" common
</VirtualHost>

######################### xxxxxxx #########################
</textarea>

<br><br>

Здесь и далее имеется в виду, что мы работаем на сервере с <code>OS Windows</code>, при этом apache и прочий необходимый системный софт установлен в папку <code>d:\xampp\</code>.

<br><br>

<b>4</b>.<br>
Создайте папку с правами на запись и чтение для хранения логов:<br>
<code>d:\web\log\fs_site.localhost\</code>

<br><br>

В эту папку у нас будут записываться логи: <code>error.log</code> и <code>access.log</code>
<br><br>



<br><hr><br>

<h4>Настройка</h4>

<b>1</b>.<br>
<b>Подключение БД</b>
<br><br>

Внесите необходимые изменения в специальный файл подключения БД:<br>
<code>d:\web\www\fs_site.localhost\config\db.php</code>

<br><br>

Это данные должны совпадать с параметрами подключения БД (см выше).

<br><br>

<br><hr><br>

Спасибо за внимание!




<br><hr><br>



<!--//
    <code>?= __FILE__ ?</code>
//-->

</div>
