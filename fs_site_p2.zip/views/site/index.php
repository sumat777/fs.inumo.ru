<?php

/** @var yii\web\View $this */

use yii\helpers\Html;

$this->title = Yii::$app->name;
// $this->title = 'My Yii Application';

$this->params['meta_description'] = Yii::$app->name . '. Программный комплес, который позволяет загружать файлы на сервер, просматривать и выгружать их.';

//$this->params['breadcrumbs'][] = $this->title;

?>
<div class="site-index">


<!--//
    <div class="jumbotron text-center bg-transparent mt-5 mb-5">
        <h1 class="display-4">Congratulations!</h1>

        <p class="lead">You have successfully created your Yii-powered application.</p>

        <p><a class="btn btn-lg btn-success" href="https://www.yiiframework.com">Get started with Yii</a></p>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4 mb-3">
                <h2>Heading</h2>

                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et
                    dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
                    ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                    fugiat nulla pariatur.</p>

                <p><a class="btn btn-outline-secondary" href="https://www.yiiframework.com/doc/">Yii Documentation &raquo;</a></p>
            </div>
            <div class="col-lg-4 mb-3">
                <h2>Heading</h2>

                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et
                    dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
                    ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                    fugiat nulla pariatur.</p>

                <p><a class="btn btn-outline-secondary" href="https://www.yiiframework.com/forum/">Yii Forum &raquo;</a></p>
            </div>
            <div class="col-lg-4">
                <h2>Heading</h2>

                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et
                    dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
                    ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                    fugiat nulla pariatur.</p>

                <p><a class="btn btn-outline-secondary" href="https://www.yiiframework.com/extensions/">Yii Extensions &raquo;</a></p>
            </div>
        </div>

    </div>

//-->

<h1><?= Html::encode($this->title) ?></h1>
<?= Html::encode($this->params['meta_description']) ?>

<br><br>
Подробная информация на странице: 
<a class="btn btn-outline-secondary" href="/web/about">О проекте &raquo;</a> 
:::::::::: 
Задать вопрос можно на странице: 
<a class="btn btn-outline-secondary" href="/web/contact">Контакты &raquo;</a>
<br><br>

<figure class="div_pic_center">
<a href="/web/fs/title/floader_girl_st04.jpg" target="_blank">
<img src="/web/fs/title/floader_girl_st04.jpg" class="pic_center_border10_width80p" alt="Девушка в рабочей строительной форме тащит огромный камень с надписью mp4 в кучу, в которой находятся разные по размеру камни с надписями jpg, gif, png." title="Девушка в рабочей строительной форме тащит огромный камень с надписью mp4 в кучу, в которой находятся разные по размеру камни с надписями jpg, gif, png.">
</a>
</figure>

<!--//
mp3, pdf, jpg, jpeg, gif, png, doc, docx, zip, xls, xlsx, rtf.
//-->
</div>
