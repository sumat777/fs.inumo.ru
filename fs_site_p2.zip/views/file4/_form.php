<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var app\models\File4 $model */
/** @var yii\widgets\ActiveForm $form */
?>

<div class="file4-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'fgroup_id')->textInput() ?>

    <?= $form->field($model, 'fnorig')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'fnserver')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'users_id')->textInput() ?>

    <?= $form->field($model, 'deleted1')->textInput() ?>

    <?= $form->field($model, 'modirec')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
