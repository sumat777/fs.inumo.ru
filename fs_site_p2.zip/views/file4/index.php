<?php

use app\models\File4;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use yii\widgets\Pjax;
/** @var yii\web\View $this */
/** @var app\models\File4Search $searchModel */
/** @var yii\data\ActiveDataProvider $dataProvider */

$this->title = 'Файлы на сервере';

$this->params['meta_description'] = 'Список загруженных на сервер файлов.';

$this->params['breadcrumbs'][] = $this->title;
?>
<div class="file4-index">

    <h1><?= Html::encode($this->title) ?></h1>


<!--//
    <p>
        ?= Html::a('Create File4', ['create'], ['class' => 'btn btn-success']) ?
    </p>
//-->

    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'fgroup_id',
            'fnorig',
            'fnserver',
            //'users_id',
            //'deleted1',
            'modirec',

            [
                'class' => ActionColumn::className(),
                'visibleButtons' => [
                  'update' => false,
                  'delete' => false,
                ],
                'urlCreator' => function ($action, File4 $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'id' => $model->id]);
                 }
            ],


/*
            [
                'class' => ActionColumn::className(),
                'urlCreator' => function ($action, File4 $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'id' => $model->id]);
                 }
            ],
*/


[ 
  'label'=>'Картинка', 
  'format' => 'raw',
//  'format' => 'html',
//  'format' => 'text',
//  'class' => ActionColumn::className(),
//  'value'=>function ($model, $index, $widget) { return $model->writerName; }
//  'value'=>function ($model, $index, $widget) { return $model->writer_id; }
  'value'=>function ($model) { 
//  'urlCreator'=>function ($model, $index, $widget) { 
  $str1  = '';
  $str1 .= '<a href="/web/file4/view?id=' . $model->id . '" target="_blank">'; 
  $str1 .= '<img src="/web/fs/1/' . $model->fnserver . '" class="pic_center minipic60" alt="' . $model->fnorig . '" title="' . $model->fnorig . '">'; 
  $str1 .= '</a>';
//  $url = '<a href="/writer/view?id=' . $model->writer_id;
//  $url = '/web/writer/view?id=' . $model->writer_id;
//  return Html::decode($str1);
//  return Html::a(trim($model->writerName), Url::to($url, true));
//  return Html::a(trim($model->writerName), Url::to($url, false));
//  return Html::a(trim($model->fnserver), $str1, ['class'=>'minipic']);
return $str1;
//  return "1";
//  return Html::a(Yii::t('app', 'Создать Произведение'), ['create'], ['class' => 'btn btn-success']);
  }
],




        ],
    ]); ?>

    <?php Pjax::end(); ?>

</div>
