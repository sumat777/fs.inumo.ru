<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/** @var yii\web\View $this */
/** @var app\models\File4 $model */


$this->title = $model->id . ' :: ' . $model->fnorig;
$this->params['meta_description'] = $this->title;

$this->params['breadcrumbs'][] = ['label' => 'Файлы', 'url' => ['index']]; // File4s
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
//
$act_link = '<a href="/web/fs/1/' . $model->fnserver . '" class="link1" target="_blank" rel="noopener noreferrer nofollow">' . $model->fnserver . '</a>';
//
$fgroup_link = '<a href="/web/fgroup/view?id=' . trim($model->fgroup_id) . '" class="link1">' . $model->fgroup_id . '</a>';
//
?>
<div class="file4-view">

    <h1><?= Html::encode($this->title) ?></h1>

<!--//
    <p>
        ?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?
        ?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?
    </p>
//-->
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
        [
            'label' => 'Группа файлов', // fgroup_id :: Fgroup ID
            'value' => $fgroup_link,
            'format' => 'raw',
        ],
            'fnorig',
        [
            'label' => 'Имя файла на сервере', // fnserver
            'value' => $act_link,
            'format' => 'raw',
        ],
            'users_id',
            'deleted1',
            'modirec',
        ],
    ]) ?>

    <figure class="div_pic_center">
    <a href="/web/fs/1/<?= $model->fnserver ?>" target="_blank">
    <img src="/web/fs/1/<?= $model->fnserver ?>" class="pic_center_border10_width80p" alt="<?= $model->fnorig ?>" title="<?= $model->fnorig ?>">
    </a>
    <figcaption>Оригинальное имя: <?= $model->fnorig ?> :: Имя на сервере: <?= $model->fnserver ?></figcaption>
    </figure>


</div>
