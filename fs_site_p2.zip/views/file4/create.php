<?php

use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\File4 $model */

$this->title = 'Create File4';
$this->params['breadcrumbs'][] = ['label' => 'File4s', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="file4-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
