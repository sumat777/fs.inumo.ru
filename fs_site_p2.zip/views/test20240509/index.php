<?php
/** @var yii\web\View $this */

use yii\helpers\Html;

$this->title = 'Тесты на проекте "' . Yii::$app->name . '"';

$this->params['meta_description'] = 'Тесты на проекте "' . Yii::$app->name . '". Здесь различные тесты, которые имеют отношение к данному проекту или в целом к фреймворку Yii2.';

$this->params['breadcrumbs'][] = $this->title;

?>

<!--//
<h1>test20240509/index</h1>
//-->

<h1><?= Html::encode($this->title) ?></h1>
<?= Html::encode($this->params['meta_description']) ?>

<!--//
<p>
    You may change the content of this page by modifying
    the file <code>?= __FILE__; ?</code>.
</p>
//-->

<br><hr><br>

<div id="test20240316">
<h3><mark>Работают ли стили, скрипты и библиотека jQuery</mark></h3>
Стиль для тестирования - подключились ли вообще дополнительные стили и скрипты, работает ли библиотека jQuery...<br>
Если все указанное выше работает, этот див должен разукраситься и отбросить тень...<br>
После клика на кнопку ниже ...
<br>
<a id="test20240316_set_style" class="btn btn-primary">Установить стиль</a>
<a id="test20240316_del_style" class="btn btn-danger">Убрать стиль</a>

<br><br>
Для справки:
<br>
Стили здесь: /web/css/bb.css<br>
Скрипты здесь: /web/js/bb.js<br>
Библиотека jQuery та, что была в поставке этой версии YII2

</div>

<br><hr><br>

<h3><mark>Тестирование процесса загрузки одного файла на сервер</mark></h3>
<br>
<a href="/web/test20240509/upload1" class="link1">Тестирование процесса загрузки одного файла на сервер</a>

<br>
<br><hr><br>

<h3><mark>Тестирование процесса загрузки нескольких файлов на сервер</mark></h3>
<br>
<a href="/web/test20240509/uploadm" class="link1">Тестирование процесса загрузки нескольких файлов на сервер</a>

<br>
<br><hr><br>

<h3><mark>Тестирование процесса загрузки нескольких файлов на сервер, версия 2.</mark></h3>
<br>
<a href="/web/test20240509/uploadmv2" class="link1">Тестирование процесса загрузки нескольких файлов на сервер, версия 2.</a>

<br>
<br><hr><br>

