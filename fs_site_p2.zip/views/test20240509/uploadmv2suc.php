<?php
/** @var yii\web\View $this */

use yii\helpers\Html;
use yii\widgets\ActiveForm;

if (empty($model)) {
  $this->title = 'Загрузка нескольких файлов. Версия 2.';
} else {
  $this->title = 'Загрузка нескольких файлов. Версия 2. Процесс прошел успешно.';
}


$this->params['meta_description'] = 'Тесты на проекте "' . Yii::$app->name . '". Загрузка нескольких файлов. Версия 2. Этот простой функционал сделан по инструкции фреймворка Yii2 с небольшими изменениями. В результате работы, в случае успеха, выбранные на локальной рабочей станции файлы загружаются на сервер. Регистрации загрузки файлов в БД не производится. Имена файлов не изменяются, что может привести к проблемам при загрузки файлов на русском языке. Разрешена загрузка файлов только со следующими расширениями: png, jpg, jpeg, gif, svg, webp.';


$this->params['breadcrumbs'][] = ['label' => 'Тесты', 'url' => ['index']]; 
$this->params['breadcrumbs'][] = ['label' => 'Загрузка нескольких файлов', 'url' => ['uploadmv2']]; 
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>

<h1><?= Html::encode($this->title) ?></h1>
<?= Html::encode($this->params['meta_description']) ?>

<br><br>

<?php
if (!empty($model)) {
?>
<a href="/web/test20240509/uploadmv2" class="link1">Повторить процесс загрузки нескольких файлов. Версия 2.</a>
<?php
}
?>
<br><br>

<!--//
<p>
    You may change the content of this page by modifying
    the file <code>?= __FILE__; ?</code>.
</p>
//-->

<br><hr><br>


<!--//
<pre>
?= 
/*
--
var_dump($model["imageFile"]->name);
--
var_dump($model["imageFile"]);
--
object(yii\web\UploadedFile)#84 (7) {
  ["name"]=>
  string(21) "test_enclosed_jpg.jpg"
  ["tempName"]=>
  string(24) "D:\xampp\tmp\php4FC5.tmp"
  ["type"]=>
  string(10) "image/jpeg"
  ["size"]=>
  int(11575)
  ["error"]=>
  int(0)
  ["fullPath"]=>
  string(21) "test_enclosed_jpg.jpg"
  ["_tempResource":"yii\web\UploadedFile":private]=>
  NULL
}
--
*/
?
</pre>
//-->


<pre>
<?php
//var_dump($model["imageFile"]);
//var_dump($model["imageFiles"]);
//var_dump($this->imageFiles);
//var_dump($this);
//var_dump($model);
//var_dump($model["descr"]);
//var_dump($_POST);
//var_dump($_POST ["Uploadmv2Form"]);
var_dump($_POST["Uploadmv2Form"]["descr"]);
// var_dump($this->descr); Getting unknown property: yii\web\View::descr
?>
</pre>


<?php
// Undefined variable $model

if (empty($model)) {
?>
<a href="/web/test20240509/uploadmv2" class="link1">Провести процесс загрузки</a>
<?php
} else {

if (empty($_POST["Uploadmv2Form"]["descr"])) {
  //$descr_gf = 'Если пользователь ввел пустое описание, то его формируем автоматом';
//  $descr_gf = 'Группа файлов ' . date("Y-m-d H:i:s");
// $date = date('m/d/Y h:i:s a', time());
$milliseconds = floor(microtime(true) * 1000);
$descr_gf = 'Группа файлов ' . date("Y-m-d H:i:s") . " :: " . time() . " :: " . $milliseconds;
} else {
  $descr_gf = $_POST["Uploadmv2Form"]["descr"];
}

  $nn = 0;
  foreach ($model["imageFiles"] as $file) {
    $nn++;
?>
    <h3 style="text-align:center;"><?= $descr_gf ?></h3>
    <br><br>
    <h4 style="text-align:center;">Файл номер <?= $nn ?></h4>
    <figure class="div_pic_center">
    <a href="/web/fs/1/<?= $file->name ?>" target="_blank">
    <img src="/web/fs/1/<?= $file->name ?>" class="pic_center_border10_width80p" alt="Загруженный файл" title="Загруженный файл">
    </a>
    <figcaption>Файл: <?= $file->name ?> :: Размер: <?= $file->size ?></figcaption>
    </figure>
    <br><br>

<?php
  }


}
?>

<br><hr><br>
