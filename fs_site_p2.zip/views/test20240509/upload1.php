<?php
/** @var yii\web\View $this */

use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Загрузка 1-го файла';

$this->params['meta_description'] = 'Тесты на проекте "' . Yii::$app->name . '". Загрузка 1-го файла. Этот простой функционал сделан по инструкции фреймворка Yii2 с небольшими изменениями. В результате работы, в случае успеха, выбранный на локальной рабочей станции файл загружается на сервер. Регистрации загрузки файла в БД не производится. Имя файла не изменяется, что может привести к проблемам при загрузки файлов на русском языке. Разрешена загрузка файлов только со следующими расширениями: png, jpg, jpeg, gif.';


$this->params['breadcrumbs'][] = ['label' => 'Тесты', 'url' => ['index']]; // Fgroups
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>

<h1><?= Html::encode($this->title) ?></h1>
<?= Html::encode($this->params['meta_description']) ?>

<br><br>

<b>Инструкция Yii 2.0 Uploading Files - Загрузка файлов</b> - <a href="https://www.yiiframework.com/doc/guide/2.0/ru/input-file-upload" class="link1" target="_blank" rel="nofollow noopener">рус</a>, <a href="https://www.yiiframework.com/doc/guide/2.0/en/input-file-upload" class="link1" target="_blank" rel="nofollow noopener">англ</a>.

<br>

<!--//
<p>
    You may change the content of this page by modifying
    the file <code>?= __FILE__; ?</code>.
</p>
//-->

<br><hr><br>

<?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]) ?>

    <?= $form->field($model, 'imageFile')->fileInput() ?>

    <button>Загрузить выбранный файл</button>

<?php ActiveForm::end() ?>

<br><hr><br>
