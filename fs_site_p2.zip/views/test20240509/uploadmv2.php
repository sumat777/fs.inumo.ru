<?php
/** @var yii\web\View $this */

use yii\helpers\Html;
use yii\widgets\ActiveForm;

$this->title = 'Загрузка нескольких файлов. Версия 2.';

$this->params['meta_description'] = 'Тесты на проекте "' . Yii::$app->name . '". Загрузка нескольких файлов. Версия 2. Этот простой функционал сделан по инструкции фреймворка Yii2 с небольшими изменениями. В результате работы, в случае успеха, выбранные на локальной рабочей станции файлы загружаются на сервер. Регистрации загрузки файлов в БД не производится. Имена файлов не изменяются, что может привести к проблемам при загрузки файлов на русском языке. Разрешена загрузка файлов только со следующими расширениями: png, jpg, jpeg, gif, svg, webp.';


$this->params['breadcrumbs'][] = ['label' => 'Тесты', 'url' => ['index']]; // Fgroups
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>

<h1><?= Html::encode($this->title) ?></h1>
<?= Html::encode($this->params['meta_description']) ?>

<br><br>

<b>Инструкция Yii 2.0 Uploading Files - Загрузка файлов</b> - <a href="https://www.yiiframework.com/doc/guide/2.0/ru/input-file-upload" class="link1" target="_blank" rel="nofollow noopener">рус</a>, <a href="https://www.yiiframework.com/doc/guide/2.0/en/input-file-upload" class="link1" target="_blank" rel="nofollow noopener">англ</a>.

<br>

<!--//
<p>
    You may change the content of this page by modifying
    the file <code>?= __FILE__; ?</code>.
</p>
//-->

<br><hr><br>

<pre>

<?php
//var_dump($model["imageFile"]);
//var_dump($model["imageFiles"]);
//var_dump($model);
//var_dump($model["descr"]);
var_dump($_POST);
//var_dump($_POST["descr"]);
//var_dump($_POST["Uploadmv2Form"]);
//var_dump($this->imageFiles);
//var_dump($this);
?>

</pre>

<br><hr><br>



<?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]) ?>

<!--//
     Для загрузки 1-го файла вот такая консрукция:
     ?= $form->field($model, 'imageFile')->fileInput() ?
 
<label class="control-label" for="fgroup-descr">Описание</label>
<input type="text" id="fgroup-descr" class="form-control" name="Fgroup[descr]" maxlength="64"> 

//-->

<?= 
$form->
field($model, 'descr')->
label('Описание группы файлов')
?>

<br><br>

<?= 
$form->
field($model, 'imageFiles[]')->
label('Файлы для загрузки')->
fileInput(['multiple'=>true, 'accept'=>'image/*', 'class'=>'ezdz2019']) 
?>
    <button>Загрузить выбранные файлы</button>

<?php ActiveForm::end() ?>

<br><br>
Важно! Сначала следует выбрать файлы для загрузки, а затем нажать кнопку "Загрузить выбранные файлы". Подготовить к загрузки нужные файлы можно методом "Драг-и-Дроп" ("Тащи-и-Бросай") или просто нажатием на область для размещения файлов. Ниже информация по выбранным файлам. 
<br><br>
Подготовлено к загрузке файлов: 
<br>
Количество: <input type="text" name="cnt1" size="4" style="background-color:#EEFFFF;">
<br>
Список:<br>
<textarea rows="5" cols="64" name="files" style="background-color:#EEFFFF;"></textarea>


<br><hr><br>
