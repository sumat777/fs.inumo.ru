<?php
/** @var yii\web\View $this */

use yii\helpers\Html;
use yii\widgets\ActiveForm;

if (empty($model)) {
  $this->title = 'Загрузка 1-го файла.';
} else {
  $this->title = 'Загрузка 1-го файла. Процесс прошел успешно.';
}


$this->params['meta_description'] = 'Тесты на проекте "' . Yii::$app->name . '". Загрузка 1-го файла. Этот простой функционал сделан по инструкции фреймворка Yii2 с небольшими изменениями. В результате работы, в случае успеха, выбранный на локальной рабочей станции файл загружается на сервер. Регистрации загрузки файла в БД не производится. Имя файла не изменяется, что может привести к проблемам при загрузки файлов на русском языке. Разрешена загрузка файлов только со следующими расширениями: png, jpg, jpeg, gif.';


$this->params['breadcrumbs'][] = ['label' => 'Тесты', 'url' => ['index']]; 
$this->params['breadcrumbs'][] = ['label' => 'Загрузка 1-го файла', 'url' => ['upload1']]; 
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>

<h1><?= Html::encode($this->title) ?></h1>
<?= Html::encode($this->params['meta_description']) ?>

<br><br>

<?php
if (!empty($model)) {
?>
<a href="/web/test20240509/upload1" class="link1">Повторить процесс загрузки</a>
<?php
}
?>
<br><br>

<!--//
<p>
    You may change the content of this page by modifying
    the file <code>?= __FILE__; ?</code>.
</p>
//-->

<br><hr><br>


<!--//
<pre>
?= 
/*
--
var_dump($model["imageFile"]->name);
--
var_dump($model["imageFile"]);
--
object(yii\web\UploadedFile)#84 (7) {
  ["name"]=>
  string(21) "test_enclosed_jpg.jpg"
  ["tempName"]=>
  string(24) "D:\xampp\tmp\php4FC5.tmp"
  ["type"]=>
  string(10) "image/jpeg"
  ["size"]=>
  int(11575)
  ["error"]=>
  int(0)
  ["fullPath"]=>
  string(21) "test_enclosed_jpg.jpg"
  ["_tempResource":"yii\web\UploadedFile":private]=>
  NULL
}
--
*/
?
</pre>
//-->

<?php
// Undefined variable $model

if (empty($model)) {
?>
<a href="/web/test20240509/upload1" class="link1">Провести процесс загрузки</a>
<?php
} else {
?>

<figure class="div_pic_center">
<a href="/web/fs/1/<?= $model["imageFile"]->name ?>" target="_blank">
<img src="/web/fs/1/<?= $model["imageFile"]->name ?>" class="pic_center_border10_width80p" alt="Загруженный файл" title="Загруженный файл">
</a>
<figcaption>Файл: <?= $model["imageFile"]->name ?> :: Размер: <?= $model["imageFile"]->size ?></figcaption>
</figure>

<?php
}
?>

<br><hr><br>
