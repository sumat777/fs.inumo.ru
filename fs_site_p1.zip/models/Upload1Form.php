<?php

namespace app\models;

use yii\base\Model;
use yii\web\UploadedFile;

class Upload1Form extends Model
{
    /**
     * @var UploadedFile
     */
    public $imageFile;

    public function rules()
    {
        return [
            [
              ['imageFile'], 
              'file', 
              'skipOnEmpty' => false, 
              'extensions' => 'png, jpg, jpeg, gif',
            ],
        ];
    }

//
// AV 20240510 uploads/ меняем на fs/1/
//
    public function upload()
    {
        if ($this->validate()) {
            $this->imageFile->saveAs('fs/1/' . $this->imageFile->baseName . '.' . $this->imageFile->extension);
            return true;
        } else {
            return false;
        }
    }

//
} // class UploadForm extends Model
//

