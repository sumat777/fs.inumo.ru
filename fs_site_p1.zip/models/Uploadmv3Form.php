<?php

namespace app\models;

use yii\base\Model;
use yii\web\UploadedFile;

class Uploadmv3Form extends Model
{
    /**
     * @var UploadedFile[]
     */
    public $imageFiles;
    public $descr;

    public function rules()
    {
        return [

/*
            [
              ['descr'], 
              'string', 
              'skipOnEmpty' => false, 
              'length' => [1, 64],
             ],
*/
            [
              ['imageFiles'], 
              'file', 
              'skipOnEmpty' => false, 
              'extensions' => 'png, jpg, jpeg, gif, svg, webp',
              'maxFiles' => 5,
            ],
        ];
    }

//
// AV 20240510 uploads/ меняем на fs/1/
//
    public function upload()
    {
        if ($this->validate()) {
            foreach ($this->imageFiles as $file) {
                $file->saveAs('fs/1/' . $file->baseName . '.' . $file->extension);
            }
            //$model["descr"] = $this->descr;
            return true;
        } else {
            return false;
        }
    }

//
} // class Uploadmv3Form extends Model
//

