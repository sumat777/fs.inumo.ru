<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "file4".
 *
 * @property int $id
 * @property int $fgroup_id
 * @property string|null $fnorig
 * @property string|null $fnserver
 * @property int $users_id
 * @property int $deleted1
 * @property string $modirec
 *
 * @property Fgroup $fgroup
 */
class File4 extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'file4';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['fgroup_id'], 'required'],
            [['fgroup_id', 'users_id', 'deleted1'], 'integer'],
            [['modirec'], 'safe'],
            [['fnorig'], 'string', 'max' => 64],
            [['fnserver'], 'string', 'max' => 32],
            [['fnserver'], 'unique'],
            [['fgroup_id'], 'exist', 'skipOnError' => true, 'targetClass' => Fgroup::class, 'targetAttribute' => ['fgroup_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'fgroup_id' => 'Группа файлов', // Fgroup ID
            'fnorig' => 'Оригинальное имя файла', // Fnorig
            'fnserver' => 'Имя файла на сервере', // Fnserver
            'users_id' => 'ID создателя/корректировщика записи', // Users ID
            'deleted1' => 'Метка к удалению (если =1)', // Deleted1
            'modirec' => 'Время записи в БД', // Modirec
        ];
    }

    /**
     * Gets query for [[Fgroup]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getFgroup()
    {
        return $this->hasOne(Fgroup::class, ['id' => 'fgroup_id']);
    }
}
