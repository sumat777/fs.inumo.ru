<?php

namespace app\models;

use yii\base\Model;
use yii\web\UploadedFile;

class UploadmForm extends Model
{
    /**
     * @var UploadedFile[]
     */
    public $imageFiles;

    public function rules()
    {
        return [
            [
              ['imageFiles'], 
              'file', 
              'skipOnEmpty' => false, 
              'extensions' => 'png, jpg, jpeg, gif',
              'maxFiles' => 5,
            ],
        ];
    }

//
// AV 20240510 uploads/ меняем на fs/1/
//
    public function upload()
    {
        if ($this->validate()) {
            foreach ($this->imageFiles as $file) {
                $file->saveAs('fs/1/' . $file->baseName . '.' . $file->extension);
            }
            return true;
        } else {
            return false;
        }
    }

//
} // class UploadForm extends Model
//

