<?php

namespace app\models;

use Yii;
use yii\base\Model;




/**
 * This is the model class for table "fgroup".
 *
 * @property int $id
 * @property string|null $descr
 * @property int $users_id
 * @property int $deleted1
 * @property string $modirec
 *
 * @property File4[] $file4s
 */
class Fgroup extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'fgroup';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['users_id', 'deleted1'], 'integer'],
            [['modirec'], 'safe'],
            [['descr'], 'string', 'length' => [1, 64], 'skipOnEmpty' => false,],
//
// AV 20240509 spec for files 
// *****

// *****
//
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'descr' => 'Описание', // 'Descr',
            'users_id' => 'ID создателя/корректировщика записи', // Users ID
            'deleted1' => 'Метка к удалению (если =1)', // Deleted1
            'modirec' => 'Время записи в БД', // Modirec
// Время внесения в БД в формате YYYY-MM-DD
        ];
    }

    /**
     * Gets query for [[File4s]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getFile4s()
    {
        return $this->hasMany(File4::class, ['fgroup_id' => 'id']);
    }
//
} // class Fgroup extends \yii\db\ActiveRecord
//
// **********************************************************
//


