<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Upload1Form;
use app\models\UploadmForm;
use app\models\Uploadmv2Form;
use yii\web\UploadedFile;

class ApiController extends Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }



//
// *****************************************************************
//




//
} // class ApiController extends Controller
//
