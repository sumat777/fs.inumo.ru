<?php

namespace app\controllers;

use app\models\File4;
use app\models\File4Search;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;


/**
 * File4Controller implements the CRUD actions for File4 model.
 */
class File4Controller extends Controller
{
    /**
     * @inheritDoc
     */

/*
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }
*/

    /**
     * Lists all File4 models.
     *
     * @return string
     */
    public function actionIndex()
    {
        $searchModel = new File4Search();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single File4 model.
     * @param int $id ID
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new File4 model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
/*
    public function actionCreate()
    {
        $model = new File4();

        if ($this->request->isPost) {
            if ($model->load($this->request->post()) && $model->save()) {
                return $this->redirect(['view', 'id' => $model->id]);
            }
        } else {
            $model->loadDefaultValues();
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }
*/



    /**
     * Updates an existing File4 model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $id ID
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
/*
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($this->request->isPost && $model->load($this->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }
*/



    /**
     * Deletes an existing File4 model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $id ID
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
/*
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }
*/



    /**
     * Finds the File4 model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param int $id ID
     * @return File4 the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = File4::findOne(['id' => $id])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

//
// ************************************************
//

public function actionApi1()
{
  \Yii::$app->response->format = \yii\web\Response:: FORMAT_JSON;

  $file4 = File4::find()->all();
  $file4cnt = count($file4);
  if($file4cnt > 0 )
  {
    return array('status'=>true, 'file4cnt'=>$file4cnt, 'data'=> $file4);
  }
    else
  {
    return array('status'=>false, 'file4cnt'=>$file4cnt, 'data'=> 'No Files Found :: Ни одного файла не найдено');
  }

/*
        return $this->render('api1', [
            'status' => false,
            'data' => 'No Files Found :: Ни одного файла не найдено',
        ]);
*/

//
} // public function actionApi1()
//

//
// ************************************************
//

public function actionApi2($id=0)
{
  \Yii::$app->response->format = \yii\web\Response:: FORMAT_JSON;

  if (empty($id)) {
    return array('status'=>false, 'data'=> 'Отсутствует идентификатор записи');
  }
  $file4 = File4::findOne(['id' => $id]);
//  $file4cnt = 0;
//  if ($file4) $file4cnt = count($file4);
//  if(count($file4cnt) > 0 )
//  if (false)
  if ($file4)
  {
    return array('status'=>true, 'data'=> $file4);
  }
    else
  {
    return array('status'=>false, 'data'=> 'Отсутствует запись с идентификатором ' . $id);
  }


//
} // public function actionApi2()
//

//
// ************************************************
//


//
} // class File4Controller extends Controller
//





