<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Upload1Form;
use app\models\UploadmForm;
use app\models\Uploadmv2Form;
use yii\web\UploadedFile;

//class Test20240509Controller extends \yii\web\Controller
class Test20240509Controller extends Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

    public function actionUpload1()
    {
        $model = new Upload1Form();

        if (Yii::$app->request->isPost) {
            $model->imageFile = UploadedFile::getInstance($model, 'imageFile');
            if ($model->upload()) {
                // file is uploaded successfully
                //return $this->render('upload1suc');
                  return $this->render('upload1suc', ['model' => $model]);
//                return;
            }
        }

        return $this->render('upload1', ['model' => $model]);
        //return $this->render('index');
    }

    public function actionUpload1suc()
    {
        // return $this->render('upload1suc');
        if (!empty($model)) {
          return $this->render('upload1suc', ['model' => $model]);
        } else {
          return $this->render('upload1suc', ['model' => null]);
          //return $this->render('upload1', ['model' => null]);
        }
    }

//
// *****************************************************************
//


    public function actionUploadm()
    {
        $model = new UploadmForm();

        if (Yii::$app->request->isPost) {
            $model->imageFiles = UploadedFile::getInstances($model, 'imageFiles');
            if ($model->upload()) {
                // file is uploaded successfully
                  return $this->render('uploadmsuc', ['model' => $model]);
            }
        }

        return $this->render('uploadm', ['model' => $model]);
    }

    public function actionUploadmsuc()
    {
        // return $this->render('uploadmsuc');
        if (!empty($model)) {
          return $this->render('uploadmsuc', ['model' => $model]);
        } else {
          return $this->render('uploadmsuc', ['model' => null]);
        }
    }

//
// *****************************************************************
//


    public function actionUploadmv2()
    {
        $model = new Uploadmv2Form();

        if (Yii::$app->request->isPost) {
            $model->imageFiles = UploadedFile::getInstances($model, 'imageFiles');
            if ($model->upload()) {
                // file is uploaded successfully
                  return $this->render('uploadmv2suc', ['model' => $model]);
            }
        }

        return $this->render('uploadmv2', ['model' => $model]);
    }

    public function actionUploadmv2suc()
    {
        // return $this->render('uploadmv2suc');
        if (!empty($model)) {
          return $this->render('uploadmv2suc', ['model' => $model]);
        } else {
          return $this->render('uploadmv2suc', ['model' => null]);
        }
    }

//
// *****************************************************************
//




//
} // class Test20240509Controller extends \yii\web\Controller
//
