<?php

namespace app\controllers;

use Yii;
use app\models\Fgroup;
use app\models\FgroupSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\UploadForm;
use yii\web\UploadedFile;
use app\models\Uploadmv3Form;
use app\models\File4;
//use app\controllers\File4;
use app\models\File4Search;


/**
 * FgroupController implements the CRUD actions for Fgroup model.
 */
class FgroupController extends Controller
{


    /**
     * @inheritDoc
     */
/*
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }
*/




    /**
     * Lists all Fgroup models.
     *
     * @return string
     */
    public function actionIndex()
    {
        $searchModel = new FgroupSearch();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Fgroup model.
     * @param int $id ID
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        $sM_File4 = new File4Search();
        $dataProvider = $sM_File4->search($this->request->queryParams);
        $dataProvider->query->andWhere('deleted1<1');
        $dataProvider->query->andWhere('fgroup_id=' . $id);


        return $this->render('view', [
            'model' => $this->findModel($id),
            'sM_File4' => $sM_File4,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Creates a new Fgroup model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
        $model = new Fgroup();

        if ($this->request->isPost) {
            if ($model->load($this->request->post()) && $model->save()) {
                return $this->redirect(['view', 'id' => $model->id]);
            }
        } else {
            $model->loadDefaultValues();
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Fgroup model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $id ID
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */

/*
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($this->request->isPost && $model->load($this->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }
*/


    /**
     * Deletes an existing Fgroup model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $id ID
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
/*
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }
*/

    /**
     * Finds the Fgroup model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param int $id ID
     * @return Fgroup the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Fgroup::findOne(['id' => $id])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }


//
// *****************************************************************
//


    public function actionUploadmv3()
    {
        $model = new Uploadmv3Form();
        $model_fg = new Fgroup();

        if (Yii::$app->request->isPost) {
            $model->imageFiles = UploadedFile::getInstances($model, 'imageFiles');
//
// получение имен файлов для хранения на сервере...
//
$cnt_files = 0;
$fnorig_ar = array();
foreach ($model["imageFiles"] as $file) {
  $fnorig_cur = $file->name;
  $fnorig_ar[$cnt_files] = $fnorig_cur;
  $cnt_files++;
  $ufname_ext = pathinfo($fnorig_cur, PATHINFO_EXTENSION);
  $fn_suf = substr('000' . trim($cnt_files), -3);
  $milliseconds = floor(microtime(true) * 1000);
  $mls3 = substr($milliseconds, -3);
  $fnserver_cur = 'f_' . date('Ymd_His') . '_' . $mls3 . '_' . $fn_suf . '.' . $ufname_ext;
  $file->name = $fnserver_cur;
//
} // foreach...
//


//
            if ($model->upload()) {
                // file is uploaded successfully
//
if (empty($_POST["Uploadmv3Form"]["descr"])) {
  //$descr_gf = 'Если пользователь ввел пустое описание, то его формируем автоматом';
//  $descr_gf = 'Группа файлов ' . date("Y-m-d H:i:s");
// $date = date('m/d/Y h:i:s a', time());
$milliseconds = floor(microtime(true) * 1000);
$mls3 = substr($milliseconds, -3);
//$descr_gf = 'Группа файлов ' . date("Y-m-d H:i:s") . " :: " . time() . " :: " . $milliseconds;
$descr_gf = 'Группа файлов ' . date("Y-m-d H:i:s") . " " . $mls3;
} else {
  $descr_gf = $_POST["Uploadmv3Form"]["descr"];
}
//
                  $model_fg["descr"] = $descr_gf;
                  //$model_fg["descr"] = 'Test descr :: Тестовое описание';
                  $model_fg->save();
                  $model_fg_id = $model_fg->id;
//
// Здесь у нас уже есть id группы, можно делать записи в Таблица: file4
//
$cnt_files = 0;
$model_f4_id_ar = array();
foreach ($model["imageFiles"] as $file) {
  $fnorig_cur = $fnorig_ar[$cnt_files];
  $fgroup_id_cur = $model_fg_id;
  $fnserver_cur = $file->name;
//
  $model_f4 = new File4();
  $model_f4->fgroup_id = $model_fg_id;
  $model_f4->fnorig = $fnorig_cur;
  $model_f4->fnserver = $fnserver_cur;
  $model_f4->save();
  $model_f4_id = $model_f4->id;
  $model_f4_id_ar[$cnt_files] = $model_f4_id;
  $cnt_files++;
//
} // foreach...
//

//
                  return $this->render('uploadmv3suc', 
                  [
                  'model' => $model, 
                  'descr_gf' => $descr_gf,
                  'model_fg_id' => $model_fg_id,
                  'cnt_files' => $cnt_files,
                  'ufname_ext' => $ufname_ext,
                  'fnorig_ar' => $fnorig_ar,
                  'model_f4_id_ar' => $model_f4_id_ar,
                  'model_f4' => $model_f4
                  ]);
//
            } // if ($model->upload()) {
//
        } // if (Yii::$app->request->isPost) {
//

        return $this->render('uploadmv3', ['model' => $model]);
    }

    public function actionUploadmv3suc()
    {
        // return $this->render('uploadmv3suc');
        if (!empty($model)) {
//          $model_fg = new Fgroup();
//          $model_fg->load($this->request->post());
//          $model["descr"] = 'Test descr :: Тестовое описание';
//          $model->save();
          return $this->render('uploadmv3suc', ['model' => $model, 'model_fg' => $model_fg]);
        } else {
          return $this->render('uploadmv3suc', ['model' => null]);
        }
    }

//
// *****************************************************************
//






//
} // class FgroupController extends Controller
//
