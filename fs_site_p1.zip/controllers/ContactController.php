<?php

namespace app\controllers;

use Yii;
//use app\models\Contact;
//use app\models\ContactSearch;
//*****
//use yii\web\Controller;
//use yii\web\NotFoundHttpException;
//use yii\filters\VerbFilter;
//use app\models\ContactForm;
use app\models\ContactrusForm;

/**
 * ContactController implements the CRUD actions for Contact model.
 */
class ContactController extends MainController
{


    /**
     * Lists all Contact models.
     *
     * @return string
     */
    public function actionIndex()
    {
//        $model = new ContactForm();
        $model = new ContactrusForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
// contact
        return $this->render('index', [
            'model' => $model,
        ]);
    }

//
} //
//

