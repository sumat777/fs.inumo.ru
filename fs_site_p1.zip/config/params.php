<?php

return [
    'adminEmail' =>  'admin@bb.inumo.ru', // admin@example.com
    'senderEmail' => 'noreply@bb.inumo.ru', // noreply@example.com
    'senderName' =>  'bb.inumo.ru mailer', // Example.com mailer
// Будем использовать емейлы Большой Б 
];
